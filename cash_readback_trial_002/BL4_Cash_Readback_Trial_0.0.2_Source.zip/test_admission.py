"""Source-only admission regression; does not import the game or the mod."""
import ast
import itertools
import sys
import zipfile
from pathlib import Path
from types import SimpleNamespace as NS

ROOT=Path(__file__).parent
source=(ROOT/'bl4_cash_readback_trial/__init__.py').read_text()

def load_functions(source, names, ns):
    tree=ast.parse(source)
    tree.body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    exec(compile(tree,'<selected source>','exec'),ns)

# Original source recovered from exact prior package during development.
old='''def idle(f):
    c = f._controller
    return (mod.is_enabled is True and f.mod.is_enabled is True
            and f.auto_master.value is False and not f._auto_owned
            and f._activation_request is None and f._auto_ground is None
            and not f.conflicting_mods()
            and (c is None or not (c.records or c.fault or c.busy or c.stop_pending is not None)))
'''
mod=NS(is_enabled=True); lines=[]; fake_sys=NS()
f=NS(mod=NS(is_enabled=True),auto_master=NS(value=False),_auto_owned=False,_activation_request=None,_auto_ground=None,conflicting_mods=lambda:False,_controller=None,_monitor_error='',_monitor_attempted=False,_monitor_candidate=False,_monitor_registered=False,monitor_status=lambda:'unavailable: not yet registered')
ns=dict(mod=mod,sys=fake_sys,LATCH='used',CONFIRM='confirm',report=lines.append,exact_foundation=lambda:f)
load_functions(source,{'idle','idle_blocker','preflight','arm'},ns)
oldns=dict(mod=mod);load_functions(old,{'idle'},oldns)
# 7 outer predicates, 4 controller predicates, plus controller absence.
count=0
for flags in itertools.product((False,True),repeat=11):
    a,b,c,d,e,g,h,i,j,k,l=flags
    mod.is_enabled=not a; f.mod.is_enabled=not b; f.auto_master.value=c; f._auto_owned=d; f._activation_request=object() if e else None; f._auto_ground=object() if g else None; f.conflicting_mods=lambda:h
    f._controller=NS(records={'x':1} if i else {},fault=j,busy=k,stop_pending='stop' if l else None)
    assert bool(oldns['idle'](f))==ns['idle'](f); count+=1
    f._controller=None
    assert bool(oldns['idle'](f))==ns['idle'](f); count+=1
mod.is_enabled=True; f.mod.is_enabled=True; f.auto_master.value=False; f._auto_owned=False; f._activation_request=None; f._auto_ground=None; f.conflicting_mods=lambda:False; f._controller=None
checks=[(mod,'is_enabled',False,'cash trial disabled'),(f.mod,'is_enabled',False,'Foundation disabled'),(f.auto_master,'value',True,'master not OFF'),(f,'_auto_owned',True,'ownership'),(f,'_activation_request',object(),'activation pending'),(f,'_auto_ground',object(),'ground activation pending'),(f,'conflicting_mods',lambda:True,'conflicting gameplay')]
for obj,key,value,label in checks:
    saved=getattr(obj,key);setattr(obj,key,value);assert label in ns['idle_blocker'](f);assert not ns['preflight']();assert label in lines[-1];setattr(obj,key,saved)
for key,val,label in [('records',{'x':1},'records remain'),('fault',True,'fault latched'),('busy',True,'controller busy'),('stop_pending','stop','restoration pending')]:
    f._controller=NS(records={},fault=False,busy=False,stop_pending=None);setattr(f._controller,key,val);assert label in ns['idle_blocker'](f);assert not ns['preflight']();assert label in lines[-1]
f._controller=None
assert ns['preflight'](); assert not hasattr(fake_sys,'used')
f._monitor_error='bad hook';assert not ns['preflight']();assert 'bad hook' in lines[-1];f._monitor_error=''
f._monitor_attempted=True;assert not ns['preflight']();assert 'prior registration failed' in lines[-1];f._monitor_attempted=False
fake_sys.used=True;assert not ns['preflight']();assert 'latch' in lines[-1];del fake_sys.used
# No native call, no hook registration on either arm failure path.
fake_sys.modules={'unrealsdk':object()}; f.ensure_monitor=lambda:False
mod.is_enabled=False;assert not ns['arm']('confirm');assert 'cash trial disabled' in lines[-1];assert fake_sys.used is True;del fake_sys.used
mod.is_enabled=True;f._monitor_error='registration failed';assert not ns['arm']('confirm');assert 'monitor registration failed' in lines[-1];assert fake_sys.used is True
print(f'{count} original/new idle equivalence combinations passed; 11 labeled blocker checks, 4 read-only preflight cases, 2 arm refusal cases passed. No game imports or native calls.')
