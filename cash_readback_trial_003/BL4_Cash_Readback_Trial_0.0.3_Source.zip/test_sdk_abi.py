"""SDK-shaped synthetic checks; never import or run the game/SDK."""
import ast, sys, threading, time, unittest
from types import SimpleNamespace as NS
from pathlib import Path
from enum import IntEnum
src=(Path(__file__).parent/'bl4_cash_readback_trial/__init__.py').read_text()
tree=ast.parse(src)
tree.body=[n for n in tree.body if not isinstance(n,(ast.Import,ast.ImportFrom)) and not (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mod' for t in n.targets))]
class Obj:
    def _get_address(self): return id(self)
class UFunction(Obj):
    def __init__(self,path,props): self.path=path;self.props=props;self.NumParams=len(props)
    def _path_name(self): return self.path
    def _properties(self): return iter(self.props)
    def _find(self,name): return next(p for p in self.props if p.Name==name)
class BoundFunction:
    def __init__(self,func,object,call=lambda *a:None): self.func=func;self.object=object;self.call=call
    def __call__(self,*a): return self.call(*a)
class Pointer(Obj):
    def __init__(self,name,kind):self._name=name;self._type=kind
class Kind(Obj):
    def __init__(self,name):self.Name=name
class Modifier(IntEnum): PostAdd=2
class Outcome(IntEnum): Success=0;Failure=1
class HookType: POST_UNCONDITIONAL=1
class Tests(unittest.TestCase):
    def setUp(self):
        self.lines=[];self.calls=[];self.fake=NS(modules={});self.mod=NS(is_enabled=True)
        self.ns=dict(sys=self.fake,threading=threading,time=time,mod=self.mod)
        exec(compile(tree,'<trial source>','exec'),self.ns);self.ns['report']=self.lines.append
        n=self.ns;self.f=NS(mod=NS(is_enabled=True),auto_master=NS(value=False),_auto_owned=False,_activation_request=None,_auto_ground=None,_controller=None,conflicting_mods=lambda:False,_monitor_registered=True,_monitor_thread=threading.get_ident(),_monitor_seen=time.monotonic(),_MONITOR_ID='foundation',_monitor_attempted=True,_monitor_candidate=True,_monitor_error='',monitor_status=lambda:'callback observed')
        self.pc=Obj();self.pawn=Obj();self.state=Obj();self.ps=Obj();self.manager=Obj();self.camera=Obj();self.pc.PlayerCameraManager=self.manager;self.pc.PlayerState=self.ps;self.manager.PCOwner=self.pc;self.camera.CameraOwner=self.manager
        self.pawn.EquippedInventorySlots=NS(items=[NS(SourceItemHandle=NS(Handle=1),ReplicationID=1,ReplicationKey=1)])
        self.fake.modules['mods_base']=NS(get_pc=lambda **kw:self.pc)
        self.kind=Kind('GbxAttributeDef');self.hk=Kind('GbxAttributeModifierHandle');self.library=Obj();self.value=1.0
        def prop(name,kind,flags): return type(kind,(),{})( )
        def props(sig,outs):
            result=[]
            for name,kind in sig:
                p=type(kind,(),{})();p.Name=name;p.ArrayDim=1;p.PropertyFlags=0x80 | (0x400 if name=='ReturnValue' else 0) | (0x100 if name in outs else 0);result.append(p)
            return result
        self.get=UFunction(n['LIB']+':GetValueOfAttribute',props(n['GET'],()))
        self.add=UFunction(n['LIB']+':AddModifierToGbxAttribute',props(n['ADD'],('attribute','ModifierActionResult')))
        self.add._find('attribute').Struct=self.kind;self.add._find('ReturnValue').Struct=self.hk
        self.library.GetValueOfAttribute=BoundFunction(self.get,self.library,lambda *a:self.value)
        def add(pointer,pawn,postadd,delta,refresh,outcome):
            self.calls.append((pointer._name,pawn,delta));self.value+=delta
            return NS(_type=self.hk),Pointer(pointer._name,self.kind),Outcome.Success
        self.library.AddModifierToGbxAttribute=BoundFunction(self.add,self.library,add)
        cls=NS(ClassDefaultObject=self.library,_find=lambda name:{'GetValueOfAttribute':self.get,'AddModifierToGbxAttribute':self.add}[name])
        self.sdk=NS(unreal=NS(BoundFunction=BoundFunction,UFunction=UFunction,FGbxDefPtr=Pointer,WeakPointer=lambda o:lambda:o),find_class=lambda name:cls,find_enum=lambda name:Modifier if 'ModifierType' in name else Outcome,hooks=NS(Type=HookType,has_hook=lambda *a:True))
        self.f.bound_session=lambda sdk:[lambda pawn:True];self.f.current_session=lambda session:(self.pc,self.pawn,self.state,True)
        self.fn=UFunction(n['PATH'],[]);self.wrapper=BoundFunction(self.fn,self.camera)
        self.ns['_pending']=(self.f,self.sdk,threading.get_ident(),time.monotonic()+3)
    def callback(self,wrapper=None): return self.ns['camera_callback'](self.camera,None,None,wrapper or self.wrapper)
    def refused(self,reason):
        self.callback();self.assertEqual(self.calls,[]);self.assertIsNone(self.ns['_pending']);self.assertIn(reason,self.lines[-1])
    def test_full_synthetic_transaction(self):
        self.assertIsNone(self.callback());self.assertEqual(self.calls,[('Att_PickupCash_Multiplier',self.pawn,1.0),('Att_PickupCash_Multiplier',self.pawn,-1.0)]);self.assertEqual(self.value,1.0);self.assertIn('NET READBACK PASS',self.lines[-1]);self.callback();self.assertEqual(len(self.calls),2)
    def test_wrong_path(self): self.fn.path='other';self.refused('path mismatch')
    def test_wrong_bound_owner(self): self.wrapper.object=Obj();self.refused('object identity mismatch')
    def test_direct_function_refused(self): self.callback(self.fn);self.assertEqual(self.calls,[]);self.assertIn('BoundFunction required',self.lines[-1])
    def test_wrong_function_type(self): self.wrapper.func=Obj();self.refused('path mismatch')
    def test_stale_monitor(self): self.f._monitor_seen-=10;self.refused('monitor unavailable')
    def test_not_standalone(self): self.f.bound_session=lambda sdk:[lambda pawn:False];self.refused('strict standalone')
    def test_nonlocal_camera(self): self.camera.CameraOwner=Obj();self.callback();self.assertEqual(self.calls,[]);self.assertIsNotNone(self.ns['_pending'])
    def test_wrong_library_owner(self): self.library.AddModifierToGbxAttribute.object=Obj();self.refused('object identity mismatch')
    def test_wrong_reflected_identity(self): self.library.AddModifierToGbxAttribute.func=UFunction(self.add.path,self.add.props);self.refused('reflected function identity')
    def test_missing_out(self): self.add._find('attribute').PropertyFlags=0x80;self.refused('return/out parameter layout')
    def test_unexpected_get_out(self): self.get._find('AttributeDef').PropertyFlags|=0x100;self.refused('return/out parameter layout')
    def test_wrong_handle_type(self): self.add._find('ReturnValue').Struct=Kind('Wrong');self.refused('handle return type')
    def test_array_param(self): self.add._find('attribute').ArrayDim=2;self.refused('scalar parameter layout')
    def test_nonunit_baseline(self): self.value=2.;self.refused('unit baseline')
    def test_preflight_uninitialized(self):
        self.f._monitor_error='not registered';self.f._monitor_attempted=self.f._monitor_candidate=self.f._monitor_registered=False;self.ns['exact_foundation']=lambda:self.f
        self.assertTrue(self.ns['preflight']());self.assertIn('not initialized',self.lines[-2]);self.assertEqual(self.calls,[]);self.assertFalse(hasattr(self.fake,self.ns['LATCH']))
    def test_preflight_real_error(self):
        self.f._monitor_error='not registered';self.f._monitor_attempted=True;self.f._monitor_candidate=self.f._monitor_registered=False;self.ns['exact_foundation']=lambda:self.f
        self.assertFalse(self.ns['preflight']());self.assertIn('HOLD',self.lines[-1]);self.assertEqual(self.calls,[])
if __name__=='__main__':unittest.main(verbosity=2)
